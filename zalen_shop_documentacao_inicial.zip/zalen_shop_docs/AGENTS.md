# AGENTS.md — Instruções para IA/Codex/Claude Code/Cursor

## 1. Prioridade

Este projeto deve ser construído com foco em:
- segurança;
- modularidade;
- clareza;
- evolução futura para multi-tenant;
- integração com Bling;
- loja visual premium.

## 2. Regras de arquitetura

- Não misturar lógica de integração dentro de componentes de UI.
- Não chamar Bling/Mercado Pago/Melhor Envio direto do frontend.
- Usar services/connectors.
- Toda tabela de loja deve ter `store_id`.
- Código deve ser TypeScript estrito.
- Validar inputs com Zod.
- Não confiar em dados enviados pelo navegador para preço, total, frete ou permissão.

## 3. Segurança

Nunca:
- expor tokens no frontend;
- salvar tokens em logs;
- usar `dangerouslySetInnerHTML` sem sanitização;
- fazer SQL concatenado;
- desativar RLS para “resolver bug”;
- aceitar webhook sem validação quando o provedor oferece assinatura;
- processar webhook sem idempotência.

## 4. Organização

Preferir estrutura:

```txt
src/
  app/
  components/
  modules/
  lib/
  server/
  types/
```

## 5. Integrações

Cada integração deve ter:
- client;
- service;
- types;
- error handling;
- logs;
- testes básicos;
- documentação.

## 6. UI

- Usar componentes reutilizáveis.
- Manter design consistente.
- Priorizar responsividade.
- Evitar animações exageradas.

## 7. Pull requests/commits

Cada mudança deve explicar:
- o que foi alterado;
- por que foi alterado;
- impacto em segurança;
- impacto em banco;
- impacto em integrações.
