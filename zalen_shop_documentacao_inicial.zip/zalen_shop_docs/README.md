# Zalen Shop — Documentação Inicial

## Visão geral

O Zalen Shop é a base para uma loja online inicialmente single-tenant, focada na primeira operação da Brasil Drones & Parts, mas estruturada para evoluir posteriormente para uma plataforma multi-tenant no estilo Nuvemshop.

A primeira versão deve priorizar uma loja visualmente forte, integrada ao Bling como ERP operacional. A Zalen será responsável pela vitrine, experiência de compra, catálogo público, layout, domínio, carrinho/pedido, painel básico e integração. O Bling seguirá como centro operacional para produtos, estoque, pedidos, nota fiscal, separação, envio, financeiro e processos internos.

## Estratégia técnica

A primeira versão deve ser construída como um app de uma loja só, mas com fundação `store_id` desde o início. Isso permite evoluir para multi-loja sem reescrever o núcleo.

## Documentos

- `PRD.md` — escopo do produto e MVP.
- `ARCHITECTURE.md` — arquitetura geral.
- `DATA_MODEL.md` — modelo de dados.
- `SECURITY.md` — regras de segurança.
- `DESIGN_SYSTEM.md` — diretrizes visuais.
- `INTEGRATIONS.md` — visão modular de integrações.
- `BLING_CONNECTOR.md` — integração com Bling.
- `PAYMENTS.md` — pagamentos e Mercado Pago.
- `SHIPPING.md` — envio, rastreio e Melhor Envio.
- `TEMPLATES.md` — modo template e modo custom.
- `ROADMAP.md` — fases de evolução.
- `AGENTS.md` — regras para IA/Codex/Claude Code/Cursor.
- `ACCEPTANCE_CRITERIA.md` — critérios de aceite.
