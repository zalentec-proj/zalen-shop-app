# Arquitetura — Zalen Shop

## 1. Stack recomendada

### Frontend e backend
- Next.js com App Router.
- React.
- TypeScript.
- Tailwind CSS.
- shadcn/ui ou componentes próprios baseados em Radix UI.
- Zod para validação.
- React Hook Form para formulários.
- TanStack Query para estado assíncrono no painel, quando necessário.

### Banco, auth e storage
- Supabase PostgreSQL.
- Supabase Auth.
- Supabase Row Level Security.
- Supabase Storage.

### Deploy
- Vercel.
- Preview deployments por branch.
- Domínios configurados na Vercel.

### Jobs e filas
- MVP: Supabase Edge Functions/Cron quando suficiente.
- Evolução: Inngest, Trigger.dev, Upstash QStash ou fila dedicada.

### Observabilidade
- Logs internos no banco.
- Sentry ou ferramenta similar para erro de aplicação.
- Vercel Analytics/Speed Insights se fizer sentido.

## 2. Estratégia single-tenant tenant-ready

A primeira versão atende apenas Brasil Drones, mas todas as tabelas centrais devem usar `store_id`.

Isso evita migração dolorosa quando o projeto virar multi-tenant.

## 3. Separação por módulos

```txt
modules/
  catalog/
  orders/
  cart/
  checkout/
  integrations/
  themes/
  shipping/
  payments/
  auth/
  security/
```

## 4. Regra de arquitetura

A interface visual não pode chamar diretamente APIs de terceiros.

Errado:

```txt
ProductPage → Bling API
Checkout → Mercado Pago direto
```

Certo:

```txt
ProductPage → banco/cache Zalen
OrderService → BlingConnector
PaymentService → MercadoPagoConnector
```

## 5. Camadas

```txt
Storefront
↓
Application Services
↓
Domain Modules
↓
Database / Connectors
↓
External APIs
```

## 6. Ambientes

- `development`
- `staging`
- `production`

Cada ambiente deve ter variáveis próprias e credenciais separadas.

## 7. Domínios

### Agora
- Loja única em domínio do cliente ou subdomínio.

### Futuro SaaS
- `zalen.tech` para marca principal.
- Domínio separado para plataforma, como `zalenshop.com.br`.
- `cliente.zalenshop.com.br` com wildcard.
- Domínio próprio para planos pagos.

## 8. Não negociar

- Tokens de integração só no backend.
- RLS em tabelas sensíveis.
- Logs de integração desde o MVP.
- Webhooks salvos antes de processar.
- Checkout recalculado no backend, se implementado.
