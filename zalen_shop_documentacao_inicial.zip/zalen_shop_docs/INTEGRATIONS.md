# Integrações — Arquitetura Modular

## 1. Princípio

Toda integração deve ser um conector modular. A loja e o painel não devem depender diretamente de provedores específicos.

## 2. Tipos de conectores

### ERP
- Bling inicial.
- Futuros: Omie, Tiny, Olist.

Interface conceitual:
```ts
interface ErpConnector {
  syncProducts(): Promise<void>
  syncStock(): Promise<void>
  createOrder(orderId: string): Promise<void>
  getOrderStatus(externalOrderId: string): Promise<void>
  handleWebhook(payload: unknown): Promise<void>
}
```

### Pagamento
- Mercado Pago previsto.
- Futuros: Asaas, Pagar.me, Stripe.

Interface conceitual:
```ts
interface PaymentConnector {
  createPayment(orderId: string): Promise<void>
  getPaymentStatus(externalPaymentId: string): Promise<void>
  refund(paymentId: string): Promise<void>
  handleWebhook(payload: unknown): Promise<void>
}
```

### Envio
- MVP: retirada, frete fixo, frete grátis, rastreio manual.
- Futuro: Melhor Envio.

Interface conceitual:
```ts
interface ShippingConnector {
  calculateRates(input: ShippingRateInput): Promise<ShippingRate[]>
  createShipment(orderId: string): Promise<void>
  getTracking(trackingCode: string): Promise<void>
}
```

### IA
- Futuro: assistente Zalen.
- Começar com eventos e recomendações estruturadas.

## 3. Regras

- Cada conector deve ter logs.
- Cada conector deve tratar erros.
- Cada conector deve suportar retries.
- Nenhum conector deve expor token no frontend.
- Webhooks devem ser salvos antes de processar.
